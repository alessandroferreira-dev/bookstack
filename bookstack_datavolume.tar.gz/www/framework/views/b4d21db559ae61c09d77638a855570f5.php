<div class="loading-container">
    <div></div>
    <div></div>
    <div></div>
    <?php if(isset($text)): ?>
        <span><?php echo e($text); ?></span>
    <?php endif; ?>
</div><?php /**PATH /app/www/resources/views/common/loading-icon.blade.php ENDPATH**/ ?>