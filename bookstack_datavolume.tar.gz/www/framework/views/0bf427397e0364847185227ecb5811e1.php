<?php $__env->startComponent('entities.list-item-basic', ['entity' => $page]); ?>
    <div class="entity-item-snippet">
        <p class="text-muted break-text"><?php echo e($page->getExcerpt()); ?></p>
    </div>
<?php echo $__env->renderComponent(); ?><?php /**PATH /app/www/resources/views/pages/parts/list-item.blade.php ENDPATH**/ ?>