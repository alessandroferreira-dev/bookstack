
<?php /**PATH /app/www/resources/views/auth/parts/login-message.blade.php ENDPATH**/ ?>